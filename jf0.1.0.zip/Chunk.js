class Chunk {
    constructor(cx, cz, seed = 0) {

        this.cx = cx;
        this.cz = cz;

        this.SIZE = 16;

        this.blocks = new Set();

        this.mesh = null;
        this.dirty = true;

        // WORLD SEED
        this.seed = seed;

        // PERLIN
        this.noise = new PerlinNoise(seed);

        this.generate();
    }

    key(x, y, z) {
        return `${x},${y},${z}`;
    }

    // =========================================
    // GENERATE TERRAIN
    // =========================================
    generate() {

        for (let x = 0; x < this.SIZE; x++) {
            for (let z = 0; z < this.SIZE; z++) {

                const wx = this.cx * this.SIZE + x;
                const wz = this.cz * this.SIZE + z;

                // =========================================
                // LANDFORM NOISE
                // =========================================
                const landforms =
                    this.noise.noise2D(
                        wx * 0.003,
                        wz * 0.003
                    );

                // =========================================
                // NOISE LAYERS
                // =========================================
                const plainsNoise =
                    this.noise.noise2D(
                        wx * 0.01,
                        wz * 0.01
                    );

                const hillNoise =
                    this.noise.noise2D(
                        wx * 0.02,
                        wz * 0.02
                    );

                const mountainNoise =
                    this.noise.noise2D(
                        wx * 0.008,
                        wz * 0.008
                    );

                const detail =
                    this.noise.noise2D(
                        wx * 0.05,
                        wz * 0.05
                    );

                // =========================================
                // SMOOTH LANDFORM WEIGHTS (NO HARD CUTS)
                // =========================================
                const plainsW = this.clamp01(
                    this.smoothstep(-0.25, -0.05, landforms)
                );

                const hillW = this.clamp01(
                    this.smoothstep(-0.15, 0.35, landforms)
                );

                const mountainW = this.clamp01(
                    this.smoothstep(0.15, 0.7, landforms)
                );

                let height = 30;

                // =========================================
                // PLAINS CONTRIBUTION
                // =========================================
                height += plainsNoise * 4 * plainsW;

                // =========================================
                // HILLS CONTRIBUTION
                // =========================================
                height += plainsNoise * 10 * hillW;
                height += hillNoise * 8 * hillW;

                // =========================================
                // MOUNTAINS (UNCHANGED LOGIC — JUST WEIGHTED)
                // =========================================
                let mountainHeight = 0;

                if (mountainW > 0) {

                    // base terrain
                    mountainHeight += plainsNoise * 8;

                    // RIDGED mountains
                    let m1 = Math.abs(
                        this.noise.noise2D(wx * 0.006, wz * 0.006)
                    );

                    let m2 = Math.abs(
                        this.noise.noise2D(wx * 0.02, wz * 0.02)
                    );

                    let m3 = Math.abs(
                        this.noise.noise2D(wx * 0.05, wz * 0.05)
                    );

                    m1 = 1 - m1;
                    m2 = 1 - m2;
                    m3 = 1 - m3;

                    m1 = Math.pow(m1, 3.5);
                    m2 = Math.pow(m2, 2.0);

                    mountainHeight += m1 * 65;
                    mountainHeight += m2 * 18;
                    mountainHeight += m3 * 4;
                }

                height += mountainHeight * mountainW;

                // =========================================
                // DETAIL
                // =========================================
                height += detail * 2;

                // =========================================
                // FINALIZE
                // =========================================
                height = Math.floor(height);
                height = Math.max(4, Math.min(80, height));

                // =========================================
                // GENERATE BLOCKS
                // =========================================
                for (let y = 0; y <= height; y++) {
                    this.blocks.add(this.key(wx, y, wz));
                }
            }
        }
    }

    // helpers
    smoothstep(min, max, v) {
        let t = this.clamp01((v - min) / (max - min));
        return t * t * (3 - 2 * t);
    }

    clamp01(v) {
        return Math.max(0, Math.min(1, v));
    }

    getBlock(x, y, z) {
        return this.blocks.has(this.key(x, y, z));
    }
}

// =====================================================
// PERLIN NOISE
// =====================================================

class PerlinNoise {

    constructor(seed) {

        this.permutation = [];

        const random = mulberry32(seed);

        for (let i = 0; i < 256; i++) {
            this.permutation[i] = i;
        }

        // SHUFFLE
        for (let i = 255; i > 0; i--) {

            const j = Math.floor(
                random() * (i + 1)
            );

            [
                this.permutation[i],
                this.permutation[j]
            ] = [
                this.permutation[j],
                this.permutation[i]
            ];
        }

        this.p = new Array(512);

        for (let i = 0; i < 512; i++) {
            this.p[i] =
                this.permutation[i % 256];
        }
    }

    fade(t) {
        return t * t * t *
            (t * (t * 6 - 15) + 10);
    }

    lerp(t, a, b) {
        return a + t * (b - a);
    }

    grad(hash, x, y) {

        const h = hash & 3;

        const u =
            h < 2 ? x : y;

        const v =
            h < 2 ? y : x;

        return (
            ((h & 1) ? -u : u) +
            ((h & 2) ? -2 * v : 2 * v)
        );
    }

    noise2D(x, y) {

        const X =
            Math.floor(x) & 255;

        const Y =
            Math.floor(y) & 255;

        x -= Math.floor(x);
        y -= Math.floor(y);

        const u = this.fade(x);
        const v = this.fade(y);

        const aa =
            this.p[this.p[X] + Y];

        const ab =
            this.p[this.p[X] + Y + 1];

        const ba =
            this.p[this.p[X + 1] + Y];

        const bb =
            this.p[this.p[X + 1] + Y + 1];

        const result = this.lerp(
            v,

            this.lerp(
                u,
                this.grad(aa, x, y),
                this.grad(ba, x - 1, y)
            ),

            this.lerp(
                u,
                this.grad(ab, x, y - 1),
                this.grad(bb, x - 1, y - 1)
            )
        );

        return result / 2;
    }
}

// =====================================================
// SEEDED RANDOM
// =====================================================

function mulberry32(a) {

    return function () {

        let t =
            a += 0x6D2B79F5;

        t = Math.imul(
            t ^ t >>> 15,
            t | 1
        );

        t ^= t + Math.imul(
            t ^ t >>> 7,
            t | 61
        );

        return (
            ((t ^ t >>> 14) >>> 0)
            / 4294967296
        );
    };
}

window.Chunk = Chunk;