class Chunk {
    constructor(cx, cz) {
        this.cx = cx;
        this.cz = cz;

        this.SIZE = 16;
        this.blocks = new Set();

        this.mesh = null;
        this.dirty = true;

        this.generate();
    }

    key(x, y, z) {
        return `${x},${y},${z}`;
    }

    generate() {
        for (let x = 0; x < this.SIZE; x++) {
            for (let z = 0; z < this.SIZE; z++) {

                const wx = this.cx * this.SIZE + x;
                const wz = this.cz * this.SIZE + z;

                const h = Math.floor(4 + Math.sin(wx * 0.1) * 2 + Math.cos(wz * 0.1) * 2);

                for (let y = 0; y <= h; y++) {
                    this.blocks.add(this.key(wx, y, wz));
                }
            }
        }
    }

    getBlock(x, y, z) {
        return this.blocks.has(this.key(x, y, z));
    }
}

window.Chunk = Chunk;