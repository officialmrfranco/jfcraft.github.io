class ChunkMesher {
    constructor(world) {
        this.world = world;

        this.dirs = [
            [1,0,0],[-1,0,0],
            [0,1,0],[0,-1,0],
            [0,0,1],[0,0,-1]
        ];
    }

    buildMesh(chunk, scene) {
        const verts = [];
        const norms = [];

        for (let pos of chunk.blocks) {
            const [x,y,z] = pos.split(",").map(Number);

            for (let d of this.dirs) {
                const nx = x + d[0];
                const ny = y + d[1];
                const nz = z + d[2];

                if (!this.world.getBlock(nx, ny, nz)) {
                    const f = this.face(x,y,z,d);
                    verts.push(...f.v);
                    norms.push(...f.n);
                }
            }
        }

        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(verts,3));
        geo.setAttribute('normal', new THREE.Float32BufferAttribute(norms,3));

        const mesh = new THREE.Mesh(
            geo,
            new THREE.MeshStandardMaterial({ color: 0x55aa55 })
        );

        scene.add(mesh);
        chunk.mesh = mesh;
        chunk.dirty = false;
    }

    face(x,y,z,d){
        const map={
            "1,0,0":[[x+1,y,z],[x+1,y+1,z],[x+1,y+1,z+1],[x+1,y,z],[x+1,y+1,z+1],[x+1,y,z+1]],
            "-1,0,0":[[x,y,z],[x,y+1,z+1],[x,y+1,z],[x,y,z],[x,y,z+1],[x,y+1,z+1]],
            "0,1,0":[[x,y+1,z],[x,y+1,z+1],[x+1,y+1,z+1],[x,y+1,z],[x+1,y+1,z+1],[x+1,y+1,z]],
            "0,-1,0":[[x,y,z],[x+1,y,z+1],[x,y,z+1],[x,y,z],[x+1,y,z],[x+1,y,z+1]],
            "0,0,1":[[x,y,z+1],[x+1,y+1,z+1],[x,y+1,z+1],[x,y,z+1],[x+1,y,z+1],[x+1,y+1,z+1]],
            "0,0,-1":[[x,y,z],[x,y+1,z],[x+1,y+1,z],[x,y,z],[x+1,y+1,z],[x+1,y,z]]
        };

        const v = map[d.join(",")];
        return { v: v.flat(), n: Array(6).fill(d).flat() };
    }
}

window.ChunkMesher = ChunkMesher;