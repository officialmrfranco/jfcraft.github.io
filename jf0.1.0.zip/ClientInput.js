class ClientInput {
    constructor() {
        this.keys = {};

        this.forward = 0;
        this.strafe = 0;
        this.jump = false;

        this.yaw = 0;
        this.pitch = 0;

        // mouse lock
        document.addEventListener("mousedown", () => {
            document.body.requestPointerLock();
        });

        // mouse look
        document.addEventListener("mousemove", (e) => {
            if (document.pointerLockElement) {
                this.yaw -= e.movementX * 0.002;
                this.pitch -= e.movementY * 0.002;

                this.pitch = Math.max(
                    -Math.PI / 2,
                    Math.min(Math.PI / 2, this.pitch)
                );
            }
        });

        // keyboard
        document.addEventListener("keydown", (e) => {
            this.keys[e.key.toLowerCase()] = true;
        });

        document.addEventListener("keyup", (e) => {
            this.keys[e.key.toLowerCase()] = false;
        });
    }

    update() {
        this.forward =
            (this.keys["w"] ? -1 : 0) +
            (this.keys["s"] ? 1 : 0);

        this.strafe =
            (this.keys["a"] ? -1 : 0) +
            (this.keys["d"] ? 1 : 0);

        this.jump = !!this.keys[" "];
    }
}

window.ClientInput = ClientInput;