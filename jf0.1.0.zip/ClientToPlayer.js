class ClientToPlayer {
    constructor(input, player) {
        this.input = input;
        this.player = player;

        // inject into server so player can access it
        player.server.input = input;
    }

    update() {
        this.player.yaw = this.input.yaw;
        this.player.pitch = this.input.pitch;
    }
}