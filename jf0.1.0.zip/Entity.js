class Entity {
    constructor(server) {
        this.server = server;

        this.pos = new THREE.Vector3();
        this.vel = new THREE.Vector3();

        this.dead = false;

        this.w = 0.6;
        this.h = 1.8;
    }

    tick(dt) {}
}