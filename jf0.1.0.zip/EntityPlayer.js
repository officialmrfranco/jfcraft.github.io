class EntityPlayer extends EntityLiving {
    constructor(server) {
        super(server, 20);

        // =====================
        // SPAWN POSITION
        // =====================
        this.pos.set(8, 9, 8);

        this.onGround = false;

        // camera control values live here (not input)
        this.yaw = 0;
        this.pitch = 0;
    }

    tick(dt) {

        const input = this.server.input; // injected later via controller

        // movement direction
        const moveZ = input.forward;
        const moveX = input.strafe;

        const dir = new THREE.Vector3(moveX, 0, moveZ).normalize();
        dir.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);

        this.vel.x = dir.x * 8;
        this.vel.z = dir.z * 8;

        this.vel.y -= 24 * dt;

        if (input.jump && this.onGround) {
            this.vel.y = 9;
            this.onGround = false;
        }

        // =====================
        // X AXIS
        // =====================
        this.pos.x += this.vel.x * dt;
        if (this.server.world.isColliding(this)) {
            this.pos.x -= this.vel.x * dt;
        }

        // =====================
        // Z AXIS
        // =====================
        this.pos.z += this.vel.z * dt;
        if (this.server.world.isColliding(this)) {
            this.pos.z -= this.vel.z * dt;
        }

        // =====================
        // Y AXIS
        // =====================
        this.pos.y += this.vel.y * dt;

        if (this.server.world.isColliding(this)) {

            if (this.vel.y < 0) {
                const top = Math.floor(this.pos.y - this.h) + 1;
                this.pos.y = top + this.h;
                this.onGround = true;
            } else {
                const bottom = Math.floor(this.pos.y);
                this.pos.y = bottom - 0.01;
            }

            this.vel.y = 0;
        } else {
            this.onGround = false;
        }
    }
}