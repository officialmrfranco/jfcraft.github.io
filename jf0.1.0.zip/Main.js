class Main {
    constructor() {

        // =====================
        // SCENE SETUP
        // =====================
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x87CEEB);

        this.camera = new THREE.PerspectiveCamera(
            90,
            innerWidth / innerHeight,
            0.1,
            1000
        );

        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(innerWidth, innerHeight);
        document.body.appendChild(this.renderer.domElement);

        this.scene.add(new THREE.AmbientLight(0xffffff, 0.6));

        const sun = new THREE.DirectionalLight(0xffffff, 0.8);
        sun.position.set(5, 10, 7);
        this.scene.add(sun);

        // =====================
        // WORLD + RENDERER
        // =====================
        this.server = {
            entities: [],
            input: null,
            world: null
        };

        this.world = new World(this.scene, this.server);
        this.server.world = this.world;

        this.gameRenderer = new Renderer(this.renderer, this.scene, this.camera);

        // =====================
        // INPUT + PLAYER
        // =====================
        this.input = new ClientInput();

        this.player = new EntityPlayer(this.server);
        this.server.entities.push(this.player);

        this.server.input = this.input;

        // link controller
        this.controller = new ClientToPlayer(this.input, this.player);

        this.last = performance.now();

        this.loop();
    }

    loop() {
        requestAnimationFrame(() => this.loop());

        const dt = Math.min((performance.now() - this.last) / 1000, 0.1);
        this.last = performance.now();

        // =====================
        // INPUT UPDATE
        // =====================
        this.input.update();

        // =====================
        // CAMERA ROTATION (FIXED HERE)
        // =====================
        this.camera.rotation.order = "YXZ";
        this.camera.rotation.y = this.input.yaw;
        this.camera.rotation.x = this.input.pitch;

        // sync player rotation
        this.player.yaw = this.input.yaw;
        this.player.pitch = this.input.pitch;

        // =====================
        // PLAYER CONTROL BRIDGE
        // =====================
        this.controller.update();

        // =====================
        // SERVER TICK (entities + world)
        // =====================
        this.world.update(this.player.pos, dt);

        // =====================
        // CAMERA FOLLOW
        // =====================
        this.camera.position.copy(this.player.pos);

        // =====================
        // RENDER
        // =====================
        this.gameRenderer.render();
    }
}

// boot
window.addEventListener("load", () => {
    new Main();
});