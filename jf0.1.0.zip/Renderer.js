class Renderer {
    constructor(renderer, scene, camera) {
        this.renderer = renderer;
        this.scene = scene;
        this.camera = camera;
    }

    render() {
        this.renderer.render(this.scene, this.camera);
    }
}

window.Renderer = Renderer;