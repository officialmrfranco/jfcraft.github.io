class World {
    constructor(scene, server) {
        this.scene = scene;
        this.server = server;

        this.chunks = new Map();
        this.CHUNK_SIZE = 16;
        this.RENDER_DISTANCE = 3;

        this.mesher = new ChunkMesher(this);
    }

    // =====================
    // CHUNK UTIL
    // =====================
    chunkKey(x, z) {
        return `${x},${z}`;
    }

    getChunk(cx, cz) {
        return this.chunks.get(this.chunkKey(cx, cz));
    }

    setChunk(cx, cz, chunk) {
        this.chunks.set(this.chunkKey(cx, cz), chunk);
    }

    // =====================
    // BLOCK ACCESS
    // =====================
    getBlock(x, y, z) {
        const cx = Math.floor(x / this.CHUNK_SIZE);
        const cz = Math.floor(z / this.CHUNK_SIZE);

        const chunk = this.getChunk(cx, cz);
        if (!chunk) return false;

        return chunk.getBlock(x, y, z);
    }

    // =====================
    // COLLISION (ENTITY AABB VS BLOCKS)
    // =====================
    isColliding(entity) {
        const m = 0.01;

        const x0 = Math.floor(entity.pos.x - entity.w / 2 + m);
        const x1 = Math.floor(entity.pos.x + entity.w / 2 - m);

        const y0 = Math.floor(entity.pos.y - entity.h + m);
        const y1 = Math.floor(entity.pos.y - m);

        const z0 = Math.floor(entity.pos.z - entity.w / 2 + m);
        const z1 = Math.floor(entity.pos.z + entity.w / 2 - m);

        for (let x = x0; x <= x1; x++) {
            for (let y = y0; y <= y1; y++) {
                for (let z = z0; z <= z1; z++) {
                    if (this.getBlock(x, y, z)) return true;
                }
            }
        }
        return false;
    }

    // =====================
    // SERVER / ENTITY TICK
    // =====================
    updateEntities(dt) {
        if (!this.server || !this.server.entities) return;

        for (let entity of this.server.entities) {
            entity.tick(dt);
        }
    }

    // =====================
    // WORLD UPDATE
    // =====================
    update(playerPos, dt) {

        // ---- entity simulation ----
        this.updateEntities(dt);

        // ---- chunk loading ----
        const cx = Math.floor(playerPos.x / this.CHUNK_SIZE);
        const cz = Math.floor(playerPos.z / this.CHUNK_SIZE);

        for (let x = -this.RENDER_DISTANCE; x <= this.RENDER_DISTANCE; x++) {
            for (let z = -this.RENDER_DISTANCE; z <= this.RENDER_DISTANCE; z++) {

                const key = this.chunkKey(cx + x, cz + z);

                if (!this.chunks.has(key)) {
                    const chunk = new Chunk(cx + x, cz + z);
                    this.setChunk(cx + x, cz + z, chunk);

                    this.mesher.buildMesh(chunk, this.scene);
                }
            }
        }
    }
}

window.World = World;