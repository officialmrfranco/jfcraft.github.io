class ChunkMesher {
    constructor(world) {
        this.world = world;
        this.dirs = [
            [1,0,0],[-1,0,0],
            [0,1,0],[0,-1,0],
            [0,0,1],[0,0,-1]
        ];
        
        // MC-style shading multipliers
        this.shading = {
            "0,1,0": 1.0,   // Top
            "0,-1,0": 0.5,  // Bottom
            "0,0,-1": 0.8,  // North
            "0,0,1": 0.8,   // South
            "-1,0,0": 0.6,  // West
            "1,0,0": 0.6    // East
        };
    }

    buildMesh(chunk, scene) {
        const verts = [];
        const colors = []; 
        const baseColor = new THREE.Color(0x55aa55);

        for (let pos of chunk.blocks) {
            const [x,y,z] = pos.split(",").map(Number);
            for (let d of this.dirs) {
                const nx = x + d[0];
                const ny = y + d[1];
                const nz = z + d[2];

                if (!this.world.getBlock(nx, ny, nz)) {
                    const f = this.face(x,y,z,d);
                    verts.push(...f.v);

                    // Get brightness for this specific face direction
                    const brightness = this.shading[d.join(",")] || 1.0;
                    
                    // Apply brightness to the base color
                    const r = baseColor.r * brightness;
                    const g = baseColor.g * brightness;
                    const b = baseColor.b * brightness;

                    // Add color for all 6 vertices of the face
                    for (let i = 0; i < 6; i++) {
                        colors.push(r, g, b);
                    }
                }
            }
        }

        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
        geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

        // Use MeshBasicMaterial + vertexColors to bypass scene lighting
        const mesh = new THREE.Mesh(
            geo,
            new THREE.MeshBasicMaterial({ 
                vertexColors: true 
            })
        );

        scene.add(mesh);
        chunk.mesh = mesh;
        chunk.dirty = false;
    }

    face(x,y,z,d){
        const map={
            "1,0,0":[[x+1,y,z],[x+1,y+1,z],[x+1,y+1,z+1],[x+1,y,z],[x+1,y+1,z+1],[x+1,y,z+1]],
            "-1,0,0":[[x,y,z],[x,y+1,z+1],[x,y+1,z],[x,y,z],[x,y,z+1],[x,y+1,z+1]],
            "0,1,0":[[x,y+1,z],[x,y+1,z+1],[x+1,y+1,z+1],[x,y+1,z],[x+1,y+1,z+1],[x+1,y+1,z]],
            "0,-1,0":[[x,y,z],[x+1,y,z+1],[x,y,z+1],[x,y,z],[x+1,y,z],[x+1,y,z+1]],
            "0,0,1":[[x,y,z+1],[x+1,y+1,z+1],[x,y+1,z+1],[x,y,z+1],[x+1,y,z+1],[x+1,y+1,z+1]],
            "0,0,-1":[[x,y,z],[x,y+1,z],[x+1,y+1,z],[x,y,z],[x+1,y+1,z],[x+1,y,z]]
        };
        return { v: map[d.join(",")].flat() };
    }
}

window.ChunkMesher = ChunkMesher;
