class Entity {
    constructor(server) {
        this.server = server;
        this.pos = new THREE.Vector3();
        this.prevPos = new THREE.Vector3(); // For interpolation
        this.vel = new THREE.Vector3();
        this.dead = false;
        this.w = 0.6;
        this.h = 1.8;
    }

    tick(dt) {
        // Record position at the start of the tick
        this.prevPos.copy(this.pos);
    }
}
