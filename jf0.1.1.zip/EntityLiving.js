class EntityLiving extends Entity {
    constructor(server, hp = 20) {
        super(server);

        this.maxHP = hp;
        this.hp = hp;
    }

    

    damage(amount) {
        this.hp -= amount;
        if (this.hp <= 0) this.dead = true;
    }
}