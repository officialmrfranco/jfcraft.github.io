class EntityPlayer extends EntityLiving {
    constructor(server) {
        super(server, 20);
        this.pos.set(8, 60, 8);
        this.onGround = false;
        this.prevPos.copy(this.pos);
        
        this.yaw = 0;
        this.pitch = 0;

        // MC Java Constants
        this.friction = 0.91; // Default block friction
        this.airDrag = 0.98;
        this.gravity = 0.08;
        this.terminalVelocity = 3.92; // Max fall speed
    }

    tick(dt) {
    this.prevPos.copy(this.pos);
    const input = this.server.input;

    // 1. HORIZONTAL DRAG (Only applies to X and Z)
    let friction = this.onGround ? (0.6 * 0.91) : 0.91;
    this.vel.x *= friction;
    this.vel.z *= friction;

    // 2. JUMPING (Set velocity BEFORE movement)
    if (input.jump && this.onGround) {
        this.vel.y = 0.42; 
        // Note: No drag is applied to the 0.42 on the very first tick it's set
    }

    // 3. HORIZONTAL ACCELERATION
    let accel = this.onGround ? 0.1 * (0.16277136 / Math.pow(0.546, 3)) : 0.02;
    const wishDir = new THREE.Vector3(input.strafe, 0, input.forward).normalize();
    wishDir.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
    this.vel.x += wishDir.x * accel;
    this.vel.z += wishDir.z * accel;

    // 4. POSITION UPDATE (Move first, then update velocity for next tick)
    this.moveWithCollision();

    // 5. VERTICAL GRAVITY & DRAG (For the NEXT tick)
    // Minecraft Logic: V_next = (V_current - gravity) * drag
    this.vel.y -= 0.08;
    this.vel.y *= 0.98;

    // 6. TERMINAL VELOCITY
    if (Math.abs(this.vel.y) > 3.92) {
        this.vel.y = Math.sign(this.vel.y) * 3.92;
    }
}


    moveWithCollision() {
        // X
        this.pos.x += this.vel.x;
        if (this.server.world.isColliding(this)) {
            this.pos.x -= this.vel.x;
            this.vel.x = 0;
        }

        // Z
        this.pos.z += this.vel.z;
        if (this.server.world.isColliding(this)) {
            this.pos.z -= this.vel.z;
            this.vel.z = 0;
        }

        // Y
        this.pos.y += this.vel.y;
        if (this.server.world.isColliding(this)) {
            if (this.vel.y < 0) {
                // Ground hit
                this.pos.y = Math.floor(this.pos.y - this.h) + 1 + this.h;
                this.onGround = true;
            } else {
                // Ceiling hit
                this.pos.y = Math.floor(this.pos.y) - 0.01;
            }
            this.vel.y = 0;
        } else {
            this.onGround = false;
        }
    }
}
