class Main {
    constructor() {

        // =====================
        // SCENE SETUP
        // =====================
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x87CEEB);

        this.tickLoop = new TickLoop(20, (dt) => {
    this.input.update();

    // ADD THIS LINE: Sync input rotation to player before physics
    this.player.yaw = this.input.yaw;
    this.player.pitch = this.input.pitch;

    this.world.update(this.player.pos, dt); 
});


        this.camera = new THREE.PerspectiveCamera(
            90,
            innerWidth / innerHeight,
            0.1,
            1000

        );

        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(innerWidth, innerHeight);
        document.body.appendChild(this.renderer.domElement);

       

        // =====================
        // WORLD + RENDERER
        // =====================
        this.server = {
            entities: [],
            input: null,
            world: null
        };

        this.world = new World(this.scene, this.server);
        this.server.world = this.world;

        this.gameRenderer = new Renderer(this.renderer, this.scene, this.camera);

        // =====================
        // INPUT + PLAYER
        // =====================
        this.input = new ClientInput();

        this.player = new EntityPlayer(this.server);
        this.server.entities.push(this.player);

        this.server.input = this.input;

        // link controller
        this.controller = new ClientToPlayer(this.input, this.player);

        this.last = performance.now();

        this.loop();
    }

    loop() {
    requestAnimationFrame(() => this.loop());

    // 1. Run as many logic ticks as needed
    this.tickLoop.update();

    // 2. Interpolate visuals (Partial Ticks)
    const p = this.tickLoop.partialTick;
    
    // Lerp the camera position between prevPos and current pos
    this.camera.position.lerpVectors(this.player.prevPos, this.player.pos, p);

    // 3. Update Camera Rotation (usually doesn't need lerp as it's raw input)
    this.camera.rotation.order = "YXZ";
    this.camera.rotation.y = this.input.yaw;
    this.camera.rotation.x = this.input.pitch;

    // 4. Render
    this.gameRenderer.render();
}
}

// boot
window.addEventListener("load", () => {
    new Main();
});