class TickLoop {
    constructor(tps = 20, onTick) {
        this.tps = tps;
        this.tickTime = 1000 / tps;
        this.onTick = onTick;
        
        this.accumulator = 0;
        this.lastTime = performance.now();
        this.partialTick = 0; // The "lerp" value (0.0 to 1.0)
    }

    update() {
        const now = performance.now();
        const delta = now - this.lastTime;
        this.lastTime = now;

        this.accumulator += delta;

        while (this.accumulator >= this.tickTime) {
            this.onTick(this.tickTime / 1000);
            this.accumulator -= this.tickTime;
        }

        // Calculate how far we are between this tick and the next
        this.partialTick = this.accumulator / this.tickTime;
    }
}

window.TickLoop = TickLoop;
